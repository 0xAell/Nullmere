// Nullmere Stillwater: aliexpress.com,aliexpress.ru,aliexpress.us##+js(set, OfflineAudioContext, undefined)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, chain, raw = '') {
    const values = {
      undefined: () => undefined,
      false: () => false,
      true: () => true,
      null: () => null,
      noopFunc: () => function () {},
      trueFunc: () => () => true,
      falseFunc: () => () => false,
      "''": () => '',
      '""': () => '',
      '': () => '',
      '{}': () => ({}),
      '[]': () => [],
      emptyObj: () => ({}),
      emptyArr: () => [],
      noopPromiseResolve: () => () => Promise.resolve(),
    };
    let make = values[raw];
    if (!make && /^-?\d{1,5}$/.test(raw)) make = () => Number(raw);
    if (!make || !chain) return;
    const value = make();
    kit.onProperty(chain, (owner, name) => {
      try {
        Object.defineProperty(owner, name, { configurable: false, get: () => value, set: () => {} });
      } catch {
        // Fixed by the page before this ran.
      }
    });
  })(kit, ...["OfflineAudioContext","undefined"]);
})();
