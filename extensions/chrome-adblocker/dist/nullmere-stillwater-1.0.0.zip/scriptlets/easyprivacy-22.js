// Nullmere Stillwater: nicovideo.jp##+js(no-xhr-if, stella)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, needle = '') {
    const pattern = kit.toRegExp(needle);
    const { open, send } = XMLHttpRequest.prototype;
    const kept = new WeakSet();
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      if (pattern.test(String(url))) kept.add(this);
      else kept.delete(this);
      return open.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function (...args) {
      if (!kept.has(this)) return send.apply(this, args);
      const request = this;
      const answer = { readyState: 4, status: 200, statusText: 'OK', response: request.responseType === 'json' ? null : '', responseText: '' };
      for (const [key, value] of Object.entries(answer)) {
        try {
          Object.defineProperty(request, key, { value, configurable: true });
        } catch {
          // responseText is not there to read for every type: leave it.
        }
      }
      setTimeout(() => {
        for (const type of ['readystatechange', 'load', 'loadend']) request.dispatchEvent(new Event(type));
      }, 1);
    };
  })(kit, ...["stella"]);
})();
