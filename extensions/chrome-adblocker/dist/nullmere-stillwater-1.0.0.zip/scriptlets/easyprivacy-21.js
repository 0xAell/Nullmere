// Nullmere Stillwater: nicovideo.jp##+js(no-fetch-if, stella)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, needle = '') {
    const pattern = kit.toRegExp(needle);
    const fetch = window.fetch;
    if (typeof fetch !== 'function') return;
    const answering = function (input, init) {
      let url = '';
      try {
        url = input instanceof Request ? input.url : String(input);
      } catch {
        // Not an address: fetch will say so.
      }
      if (pattern.test(url)) return Promise.resolve(new Response('', { status: 200, statusText: 'OK' }));
      return fetch.apply(this, [input, init]);
    };
    Object.defineProperty(answering, 'name', { value: 'fetch' });
    answering.toString = () => fetch.toString();
    window.fetch = answering;
  })(kit, ...["stella"]);
})();
