// Nullmere Stillwater: usaa.com##+js(set-cookie, GPC, 1, , reload, 1)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, name, raw = '', path = '', ...options) {
    if (!name || !/^[\w.-]+$/.test(name)) return;
    const plain = ['true', 'false', 'yes', 'no', 'y', 'n', 'ok', 'on', 'off', 'accept', 'reject', 'accepted', 'rejected', 'allow', 'deny', ''];
    if (!plain.includes(raw) && !/^\d{1,5}$/.test(raw)) return;
    const named = {};
    for (let i = 0; i + 1 < options.length; i += 2) named[options[i]] = options[i + 1];
    const has = () => document.cookie.split(';').some((part) => part.trim() === `${name}=${raw}`);
    if (has()) return;
    const where = path === '/' || path === '' ? '/' : path === 'none' ? '' : '/';
    document.cookie = `${name}=${raw}; max-age=31536000${where ? `; path=${where}` : ''}`;
    if (named.reload === '1' && has()) window.location.reload();
  })(kit, ...["GPC","1","","reload","1"]);
})();
