// Nullmere Stillwater: mensjournal.com##+js(json-edit, ..props.children.*[?.key=="admiral-script"])
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
  readJsonq: function (query) {
  const steps = [];
  const name = /^[A-Za-z_$][\w$-]*/;
  let rest = String(query).trim();
  if (!rest) return null;
  while (rest) {
    let found;
    if ((found = /^(\.\.?)(\*|[A-Za-z_$][\w$-]*)/.exec(rest))) {
      steps.push({ deep: found[1] === '..', key: found[2] });
    } else if ((found = /^\[(\d+)\]/.exec(rest))) {
      steps.push({ deep: false, key: found[1] });
    } else if ((found = /^\[\?((?:\.[A-Za-z_$][\w$-]*)+)(?:\s*(==|!=|\^=|\$=|\*=)\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false|null))?\]/.exec(rest))) {
      const path = found[1].slice(1).split('.');
      if (!path.every((part) => name.test(part))) return null;
      let value;
      if (found[3] !== undefined) {
        const literal = found[3].startsWith("'") ? `"${found[3].slice(1, -1).replaceAll('"', '\\"')}"` : found[3];
        try {
          value = JSON.parse(literal);
        } catch {
          return null;
        }
      }
      steps.push({ where: path, op: found[2] ?? 'has', value });
    } else {
      return null;
    }
    rest = rest.slice(found[0].length);
  }
  // A query that finds the whole of what was read takes nothing out.
  return steps.some((step) => step.key !== undefined) ? steps : null;
},
  editJson: function (steps, root) {
  const holds = (node) => node !== null && typeof node === 'object';
  // Each found thing as [what holds it, its key, itself].
  let found = [[null, null, root]];
  const children = (node) => (holds(node) ? Object.keys(node).map((key) => [node, key, node[key]]) : []);
  const descendants = (node) => {
    const all = [];
    const walk = (parent) => {
      for (const entry of children(parent)) {
        all.push(entry);
        if (all.length > 100000) return;
        walk(entry[2]);
      }
    };
    walk(node);
    return all;
  };
  for (const step of steps) {
    if (step.where) {
      found = found.filter(([, , node]) => {
        let at = node;
        for (const part of step.where) {
          if (!holds(at) || !(part in at)) return false;
          at = at[part];
        }
        if (step.op === 'has') return true;
        if (step.op === '==') return at === step.value;
        if (step.op === '!=') return at !== step.value;
        const text = String(at);
        const wanted = String(step.value);
        return step.op === '^=' ? text.startsWith(wanted) : step.op === '$=' ? text.endsWith(wanted) : text.includes(wanted);
      });
      continue;
    }
    const next = [];
    for (const [, , node] of found) {
      const among = step.deep ? [[null, null, node], ...descendants(node)].flatMap(([, , inner]) => children(inner)) : children(node);
      for (const entry of among) if (step.key === '*' || entry[1] === step.key) next.push(entry);
    }
    found = [...new Map(next.map((entry) => [entry[2] !== null && typeof entry[2] === 'object' ? entry[2] : entry, entry])).values()];
  }
  // Out of each array from its last item back, so the others keep their places.
  const out = found.filter(([parent]) => parent !== null);
  const items = new Map();
  for (const [parent, key] of out) {
    if (Array.isArray(parent)) items.set(parent, [...(items.get(parent) ?? []), Number(key)]);
    else delete parent[key];
  }
  for (const [array, indices] of items) for (const index of indices.sort((a, b) => b - a)) array.splice(index, 1);
  return out.length;
},
};
(function (kit, query = '') {
    const steps = kit.readJsonq(query);
    if (!steps) return;
    const parse = JSON.parse;
    const edited = function (...args) {
      const value = parse.apply(this, args);
      try {
        kit.editJson(steps, value);
      } catch {
        // What can't be edited is given as it came.
      }
      return value;
    };
    Object.defineProperty(edited, 'name', { value: 'parse' });
    edited.toString = () => parse.toString();
    JSON.parse = edited;
  })(kit, ...["..props.children.*[?.key==\"admiral-script\"]"]);
})();
