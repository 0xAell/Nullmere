// Nullmere Stillwater: iphoneincanada.ca##+js(acs, document.createElement, __apNoHold)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, chain, needle = '') {
    if (!chain) return;
    const pattern = kit.toRegExp(needle);
    const mark = `Stillwater stopped a script ${Math.random().toString(36).slice(2)}`;
    kit.quietly(mark);
    const check = () => {
      const script = document.currentScript;
      if (!(script instanceof HTMLScriptElement)) return;
      const said = script.src || script.textContent || '';
      if (pattern.test(said)) throw new ReferenceError(mark);
    };
    kit.onProperty(chain, (owner, name) => {
      let value;
      try {
        value = owner[name];
      } catch {
        return;
      }
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get() {
            check();
            return value;
          },
          set(next) {
            check();
            value = next;
          },
        });
      } catch {
        // Fixed by the page before this ran.
      }
    });
  })(kit, ...["document.createElement","__apNoHold"]);
})();
