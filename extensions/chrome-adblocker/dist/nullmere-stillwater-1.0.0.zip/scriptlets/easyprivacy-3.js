// Nullmere Stillwater: madewell.com##+js(cookie-remover, dns_cookie)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, needle = '') {
    const pattern = kit.toRegExp(needle);
    const remove = () => {
      const parts = window.location.hostname.split('.');
      const domains = [''];
      for (let i = 0; i < parts.length - 1; i++) domains.push(`; domain=.${parts.slice(i).join('.')}`);
      for (const part of document.cookie.split(';')) {
        const name = part.split('=')[0].trim();
        if (!name || !pattern.test(name)) continue;
        for (const domain of domains) {
          for (const path of ['', '; path=/']) document.cookie = `${name}=; max-age=0${path}${domain}`;
        }
      }
    };
    remove();
    window.addEventListener('beforeunload', remove);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') remove();
    });
  })(kit, ...["dns_cookie"]);
})();
