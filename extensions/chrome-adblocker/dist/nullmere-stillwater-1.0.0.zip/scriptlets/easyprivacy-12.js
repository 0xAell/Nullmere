// Nullmere Stillwater: al.com,attackofthefanboy.com,beavertonvalleytimes.com,destructoid.com,gamepur.com,gamerjournalist.com,gameskinny.com,lehighvalleylive.com,lehighvalleylivecom,lgbtqnation.com,macwelt.de,masslive.com,mlive.com,news8000.com,oregonlive.com,pcwelt.de,pennlive.com,portlandtribune.com,primagames.com,progameguides.com,queerty.com,siliconera.com,silive.com,sporcle.com,techcrunch.com,thebeenews.com,themarysue.com,theoutlookonline.com,touchtapplay.com,wegotthiscovered.com##+js(aost, decodeURI, /(?=^(?!.*\.js))/)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, chain, needle = '') {
    if (!chain) return;
    const pattern = kit.toRegExp(needle);
    const mark = `Stillwater stopped a caller ${Math.random().toString(36).slice(2)}`;
    kit.quietly(mark);
    const own = /chrome-extension:\/\//;
    const check = () => {
      const stack = String(new Error().stack ?? '')
        .split('\n')
        .slice(1)
        .filter((line) => !own.test(line))
        .join('\n');
      if (pattern.test(stack)) throw new ReferenceError(mark);
    };
    kit.onProperty(chain, (owner, name) => {
      let value;
      try {
        value = owner[name];
      } catch {
        return;
      }
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get() {
            check();
            return value;
          },
          set(next) {
            check();
            value = next;
          },
        });
      } catch {
        // Fixed by the page before this ran.
      }
    });
  })(kit, ...["decodeURI","/(?=^(?!.*\\.js))/"]);
})();
