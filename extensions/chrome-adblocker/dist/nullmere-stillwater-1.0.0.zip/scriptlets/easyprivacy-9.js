// Nullmere Stillwater: 10tv.com,11alive.com,12news.com,12newsnow.com,13newsnow.com,13wmaz.com,5newsonline.com,9news.com,abc10.com,al.com,aol.com,apnews.com,artforum.com,artnews.com,bellinghamherald.com,billboard.com,birdsandblooms.com,calgaryherald.com,calgarysun.com,cbs19.tv,cbs8.com,chattanoogacw.com,cleveland.com,crooksandliars.com,cwtv.com,deadline.com,dpreview.com,driving.ca,edmontonjournal.com,edmontonsun.com,familyhandyman.com,financialpost.com,firstcoastnews.com,fox43.com,fox61.com,futbin.com,goldderby.com,golfdigest.com,gulflive.com,hollywoodreporter.com,indiewire.com,kare11.com,kcentv.com,kens5.com,kgw.com,khou.com,kiiitv.com,king5.com,komonews.com,krem.com,ktvb.com,kvue.com,lehighvalleylive.com,lfpress.com,localmemphis.com,masslive.com,mlive.com,motor1.com,myfoxzone.com,nationalpost.com,nbcsports.com,news.com.au,newscentermaine.com,newswest9.com,nj.com,nydailynews.com,oregonlive.com,ottawacitizen.com,ottawasun.com,pcworld.com,pennlive.com,rd.com,robbreport.com,rollingstone.com,sherdog.com,sidereel.com,silive.com,sportico.com,superherohype.com,syracuse.com,tasteofhome.com,techcrunch.com,thehealthy.com,thv11.com,tj.news,torontosun.com,twinfinite.net,vancouversun.com,variety.com,vibe.com,wbir.com,wcnc.com,weareiowa.com,weather.com,wfaa.com,wfmynews2.com,wgrz.com,whas11.com,windsorstar.com,wkyc.com,wltx.com,wnep.com,wowhead.com,wqad.com,wthr.com,wtol.com,wtsp.com,wusa9.com,wwd.com,wwltv.com,wzzm13.com##+js(acs, document.getElementsByTagName, .pubads)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, chain, needle = '') {
    if (!chain) return;
    const pattern = kit.toRegExp(needle);
    const mark = `Stillwater stopped a script ${Math.random().toString(36).slice(2)}`;
    kit.quietly(mark);
    const check = () => {
      const script = document.currentScript;
      if (!(script instanceof HTMLScriptElement)) return;
      const said = script.src || script.textContent || '';
      if (pattern.test(said)) throw new ReferenceError(mark);
    };
    kit.onProperty(chain, (owner, name) => {
      let value;
      try {
        value = owner[name];
      } catch {
        return;
      }
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get() {
            check();
            return value;
          },
          set(next) {
            check();
            value = next;
          },
        });
      } catch {
        // Fixed by the page before this ran.
      }
    });
  })(kit, ...["document.getElementsByTagName",".pubads"]);
})();
