// Nullmere Stillwater: search.rakuten.co.jp##+js(aeld, mouseup, sendClickEvent)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, type = '', needle = '') {
    const types = kit.toRegExp(type);
    const pattern = kit.toRegExp(needle);
    const add = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function (kind, listener, ...rest) {
      let code = '';
      try {
        code = String(typeof listener === 'function' ? listener : listener?.handleEvent ?? '');
      } catch {
        // A listener that won't be read is not one to judge.
      }
      if (types.test(String(kind)) && pattern.test(code)) return undefined;
      return add.call(this, kind, listener, ...rest);
    };
  })(kit, ...["mouseup","sendClickEvent"]);
})();
