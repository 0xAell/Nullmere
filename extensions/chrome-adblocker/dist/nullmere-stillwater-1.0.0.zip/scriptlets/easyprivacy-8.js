// Nullmere Stillwater: 247sports.com,al.com,arstechnica.com,bringmethenews.com,cattime.com,cbr.com,cheatsheet.com,collider.com,comingsoon.net,crooksandliars.com,cwtv.com,dogtime.com,esportstales.com,forums.hfboards.com,freep.com,fresnobee.com,gamerant.com,gbatemp.net,golfdigest.com,grabify.link,hancinema.net,hemmings.com,howtogeek.com,ijr.com,informazionefiscale.it,inquirer.net,insider-gaming.com,knowyourmeme.com,magesypro.pro,makeuseof.com,mlive.com,money.it,motorbiscuit.com,movieweb.com,nationalreview.com,nbcnews.com,neopets.com,nofilmschool.com,nypost.com,omg.blog,order-order.com,oregonlive.com,pcwelt.de,pennlive.com,playstationlifestyle.net,pwinsider.com,savvytime.com,screenrant.com,siliconera.com,simpleflying.com,sporcle.com,stealthoptional.com,techlicious.com,technicpack.net,thedraftnetwork.com,thefashionspot.com,thegamer.com,thelayoff.com,thenerdstash.com,theprovince.com,titantv.com,topspeed.com,twinfinite.net,videogamer.com,webmail.wiki,wnd.com,worldpopulationreview.com,wral.com,wrestlezone.com,wrestlinginc.com,xda-developers.com##+js(acs, document.createElement, admiral)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, chain, needle = '') {
    if (!chain) return;
    const pattern = kit.toRegExp(needle);
    const mark = `Stillwater stopped a script ${Math.random().toString(36).slice(2)}`;
    kit.quietly(mark);
    const check = () => {
      const script = document.currentScript;
      if (!(script instanceof HTMLScriptElement)) return;
      const said = script.src || script.textContent || '';
      if (pattern.test(said)) throw new ReferenceError(mark);
    };
    kit.onProperty(chain, (owner, name) => {
      let value;
      try {
        value = owner[name];
      } catch {
        return;
      }
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get() {
            check();
            return value;
          },
          set(next) {
            check();
            value = next;
          },
        });
      } catch {
        // Fixed by the page before this ran.
      }
    });
  })(kit, ...["document.createElement","admiral"]);
})();
