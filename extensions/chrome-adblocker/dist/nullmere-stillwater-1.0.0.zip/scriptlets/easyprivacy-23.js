// Nullmere Stillwater: abema.tv##+js(rmnt, script, NREUM)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, nodeName, needle = '') {
    if (!nodeName) return;
    const names = kit.toRegExp(/^\/.*\/[a-z]*$/.test(nodeName) ? nodeName : `/^${nodeName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$/i`);
    const pattern = kit.toRegExp(needle);
    const look = (node) => {
      if (!names.test(node.nodeName)) return;
      if (!pattern.test(node.textContent ?? '')) return;
      node.textContent = '';
      node.remove?.();
    };
    const each = (node) => {
      look(node);
      if (node.querySelectorAll) for (const inner of node.querySelectorAll('*')) look(inner);
    };
    new MutationObserver((records) => {
      for (const record of records) for (const node of record.addedNodes) each(node);
    }).observe(document, { childList: true, subtree: true });
    each(document);
  })(kit, ...["script","NREUM"]);
})();
