// Nullmere Stillwater: coomer.st,kemono.cr,official.coomer.com.co##+js(set-local-storage-item, plausible_ignore, true)
(() => {
const kit = {
  toRegExp: function (needle) {
    if (needle === undefined || needle === '') return /^/;
    const literal = /^\/(.+)\/([dgimsuy]*)$/.exec(needle);
    if (literal) {
      try {
        return new RegExp(literal[1], literal[2]);
      } catch {
        return /(?!)/;
      }
    }
    return new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  },
  onProperty: function (chain, then) {
    const reach = (owner, path) => {
      const [name, ...rest] = path;
      if (!rest.length) {
        then(owner, name);
        return;
      }
      let inner;
      try {
        inner = owner[name];
      } catch {
        return;
      }
      if (inner instanceof Object) {
        reach(inner, rest);
        return;
      }
      // Not made yet: when it is, reach on into it.
      try {
        Object.defineProperty(owner, name, {
          configurable: true,
          get: () => inner,
          set(next) {
            inner = next;
            if (next instanceof Object) reach(next, rest);
          },
        });
      } catch {
        // A property the page has fixed already: nothing to be done.
      }
    };
    reach(window, chain.split('.'));
  },
  quietly: function (mark) {
    window.addEventListener('error', (event) => {
      if (String(event.message).includes(mark)) event.preventDefault();
    });
  },
};
(function (kit, key, raw = '') {
    if (!key) return;
    const plain = ['undefined', 'false', 'true', 'null', 'yes', 'no', 'on', 'off', 'accept', 'reject', 'accepted', 'rejected', ''];
    try {
      if (raw === '$remove$') localStorage.removeItem(key);
      else if (plain.includes(raw) || /^\d{1,5}$/.test(raw)) localStorage.setItem(key, raw);
      else if (raw === 'emptyArr' || raw === 'emptyObj') localStorage.setItem(key, raw === 'emptyArr' ? '[]' : '{}');
    } catch {
      // Storage the page may not use.
    }
  })(kit, ...["plausible_ignore","true"]);
})();
